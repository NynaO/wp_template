/*Masonry initialization script*/
jQuery( document ).ready( function( $ ) {
    $( '#grid-container' ).masonry( { columnWidth: 220 } );
} );